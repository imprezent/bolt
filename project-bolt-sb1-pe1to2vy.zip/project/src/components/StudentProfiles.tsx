import React, { useState } from 'react';
import { 
  User, 
  Brain, 
  Heart, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle, 
  MessageSquare,
  BookOpen,
  Users,
  Target,
  Clock,
  Award,
  Lightbulb,
  FileText,
  BarChart3,
  PieChart,
  Activity,
  Plus,
  Save,
  X
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { useApp } from '../contexts/AppContext';

interface StudentProfile {
  id: string;
  name: string;
  studentId: string;
  grade: string;
  photo: string;
  personality: {
    learningStyle: string;
    strengths: string[];
    challenges: string[];
    motivation: string;
    socialStyle: string;
  };
  academic: {
    overallGrade: number;
    subjects: {
      name: string;
      grade: number;
      trend: 'up' | 'down' | 'stable';
    }[];
    attendance: number;
    participation: number;
  };
  behavioral: {
    discipline: number;
    cooperation: number;
    leadership: number;
    creativity: number;
    responsibility: number;
  };
  recommendations: {
    teaching: string[];
    support: string[];
    development: string[];
  };
  notes: {
    date: string;
    content: string;
    type: 'academic' | 'behavioral' | 'personal';
  }[];
  progressData: {
    month: string;
    score: number;
  }[];
}

const StudentProfiles: React.FC = () => {
  const { t, settings } = useApp();
  const [selectedStudent, setSelectedStudent] = useState<string>('');
  const [activeTab, setActiveTab] = useState('overview');
  const [showAddNoteModal, setShowAddNoteModal] = useState(false);
  const [newNote, setNewNote] = useState({
    content: '',
    type: 'academic' as 'academic' | 'behavioral' | 'personal'
  });
  const [showAddStudentModal, setShowAddStudentModal] = useState(false);
  const [newStudent, setNewStudent] = useState({
    name: '',
    studentId: '',
    grade: settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班',
    photo: 'https://images.pexels.com/photos/1462630/pexels-photo-1462630.jpeg'
  });

  const [students, setStudents] = useState<StudentProfile[]>([
    {
      id: '1',
      name: t('student.somjai'),
      studentId: '12345',
      grade: settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班',
      photo: 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg',
      personality: {
        learningStyle: settings.language === 'th' ? 'Visual Learner - เรียนรู้ผ่านการมองเห็น' :
                       settings.language === 'en' ? 'Visual Learner - Learns through seeing' :
                       'Visual Learner - 通过视觉学习',
        strengths: settings.language === 'th' ? 
          ['มีความคิดสร้างสรรค์', 'ชอบการทำงานกลุ่ม', 'มีความรับผิดชอบสูง'] :
          settings.language === 'en' ?
          ['Creative', 'Enjoys group work', 'Highly responsible'] :
          ['有创造力', '喜欢小组工作', '责任心强'],
        challenges: settings.language === 'th' ?
          ['ขาดความมั่นใจในการพูดหน้าชั้น', 'ต้องการเวลาในการทำความเข้าใจ'] :
          settings.language === 'en' ?
          ['Lacks confidence in speaking in front of class', 'Needs time to understand'] :
          ['缺乏在课堂前发言的信心', '需要时间理解'],
        motivation: settings.language === 'th' ? 'ชอบได้รับการยกย่องและคำชม' :
                    settings.language === 'en' ? 'Likes to receive recognition and praise' :
                    '喜欢得到认可和赞扬',
        socialStyle: settings.language === 'th' ? 'เป็นมิตร แต่ค่อนข้างเงียบ' :
                     settings.language === 'en' ? 'Friendly but relatively quiet' :
                     '友好但相对安静'
      },
      academic: {
        overallGrade: 84,
        subjects: [
          { 
            name: settings.language === 'th' ? 'ภาษาไทย' : settings.language === 'en' ? 'Thai Language' : '泰语', 
            grade: 88, 
            trend: 'up' 
          },
          { 
            name: settings.language === 'th' ? 'คณิตศาสตร์' : settings.language === 'en' ? 'Mathematics' : '数学', 
            grade: 76, 
            trend: 'stable' 
          },
          { 
            name: settings.language === 'th' ? 'วิทยาศาสตร์' : settings.language === 'en' ? 'Science' : '科学', 
            grade: 82, 
            trend: 'up' 
          },
          { 
            name: settings.language === 'th' ? 'สังคมศึกษา' : settings.language === 'en' ? 'Social Studies' : '社会研究', 
            grade: 90, 
            trend: 'up' 
          },
          { 
            name: settings.language === 'th' ? 'ภาษาอังกฤษ' : settings.language === 'en' ? 'English' : '英语', 
            grade: 78, 
            trend: 'down' 
          }
        ],
        attendance: 95,
        participation: 75
      },
      behavioral: {
        discipline: 90,
        cooperation: 95,
        leadership: 70,
        creativity: 85,
        responsibility: 92
      },
      recommendations: {
        teaching: settings.language === 'th' ?
          ['ใช้สื่อภาพและแผนภูมิในการสอน', 'ให้โอกาสนำเสนองานในกลุ่มเล็ก', 'สร้างความมั่นใจด้วยการให้คำชมเมื่อทำได้ดี'] :
          settings.language === 'en' ?
          ['Use visual aids and charts in teaching', 'Provide opportunities to present in small groups', 'Build confidence by giving praise when doing well'] :
          ['在教学中使用视觉辅助工具和图表', '提供在小组中展示的机会', '通过在表现良好时给予表扬来建立信心'],
        support: settings.language === 'th' ?
          ['ให้เวลาเพิ่มเติมในการทำความเข้าใจ', 'จัดกิจกรรมเสริมสร้างความมั่นใจ', 'ส่งเสริมการมีส่วนร่วมในชั้นเรียน'] :
          settings.language === 'en' ?
          ['Give additional time for understanding', 'Organize confidence-building activities', 'Encourage classroom participation'] :
          ['给予额外的理解时间', '组织建立信心的活动', '鼓励课堂参与'],
        development: settings.language === 'th' ?
          ['พัฒนาทักษะการนำเสนอ', 'เสริมสร้างความมั่นใจในตนเอง', 'ฝึกทักษะการคิดเชิงตรรกะ'] :
          settings.language === 'en' ?
          ['Develop presentation skills', 'Build self-confidence', 'Practice logical thinking skills'] :
          ['发展演讲技能', '建立自信', '练习逻辑思维技能']
      },
      notes: [
        {
          date: '2024-01-15',
          content: settings.language === 'th' ? 
            'นักเรียนมีความก้าวหน้าในวิชาสังคมศึกษาอย่างชัดเจน แสดงความสนใจในเรื่องประวัติศาสตร์' :
            settings.language === 'en' ? 
            'Student shows clear progress in Social Studies, showing interest in history' :
            '学生在社会研究方面有明显进步，对历史表现出兴趣',
          type: 'academic'
        },
        {
          date: '2024-01-10',
          content: settings.language === 'th' ? 
            'ควรส่งเสริมให้มีส่วนร่วมในการอภิปรายมากขึ้น เพื่อเสริมสร้างความมั่นใจ' :
            settings.language === 'en' ? 
            'Should encourage more participation in discussions to build confidence' :
            '应鼓励更多参与讨论以建立信心',
          type: 'behavioral'
        }
      ],
      progressData: [
        { month: settings.language === 'th' ? 'ส.ค.' : settings.language === 'en' ? 'Aug' : '8月', score: 78 },
        { month: settings.language === 'th' ? 'ก.ย.' : settings.language === 'en' ? 'Sep' : '9月', score: 80 },
        { month: settings.language === 'th' ? 'ต.ค.' : settings.language === 'en' ? 'Oct' : '10月', score: 82 },
        { month: settings.language === 'th' ? 'พ.ย.' : settings.language === 'en' ? 'Nov' : '11月', score: 81 },
        { month: settings.language === 'th' ? 'ธ.ค.' : settings.language === 'en' ? 'Dec' : '12月', score: 84 },
        { month: settings.language === 'th' ? 'ม.ค.' : settings.language === 'en' ? 'Jan' : '1月', score: 84 }
      ]
    },
    {
      id: '2',
      name: t('student.somsak'),
      studentId: '12346',
      grade: settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班',
      photo: 'https://images.pexels.com/photos/1043471/pexels-photo-1043471.jpeg',
      personality: {
        learningStyle: settings.language === 'th' ? 'Kinesthetic Learner - เรียนรู้ผ่านการลงมือทำ' :
                       settings.language === 'en' ? 'Kinesthetic Learner - Learns through doing' :
                       'Kinesthetic Learner - 通过实践学习',
        strengths: settings.language === 'th' ? 
          ['มีความสามารถทางคณิตศาสตร์', 'มีภาวะผู้นำ', 'กระตือรือร้นในการเรียน'] :
          settings.language === 'en' ?
          ['Strong in mathematics', 'Has leadership qualities', 'Enthusiastic about learning'] :
          ['数学能力强', '具有领导才能', '学习热情高'],
        challenges: settings.language === 'th' ?
          ['ไม่ชอบงานที่ต้องนั่งนิ่ง', 'บางครั้งรีบร้อนเกินไป'] :
          settings.language === 'en' ?
          ['Dislikes sedentary tasks', 'Sometimes too hasty'] :
          ['不喜欢静坐的任务', '有时太过匆忙'],
        motivation: settings.language === 'th' ? 'ชอบความท้าทายและการแข่งขัน' :
                    settings.language === 'en' ? 'Enjoys challenges and competition' :
                    '喜欢挑战和竞争',
        socialStyle: settings.language === 'th' ? 'เป็นผู้นำธรรมชาติ มีเพื่อนมาก' :
                     settings.language === 'en' ? 'Natural leader with many friends' :
                     '天生的领导者，朋友众多'
      },
      academic: {
        overallGrade: 91,
        subjects: [
          { 
            name: settings.language === 'th' ? 'ภาษาไทย' : settings.language === 'en' ? 'Thai Language' : '泰语', 
            grade: 85, 
            trend: 'stable' 
          },
          { 
            name: settings.language === 'th' ? 'คณิตศาสตร์' : settings.language === 'en' ? 'Mathematics' : '数学', 
            grade: 95, 
            trend: 'up' 
          },
          { 
            name: settings.language === 'th' ? 'วิทยาศาสตร์' : settings.language === 'en' ? 'Science' : '科学', 
            grade: 92, 
            trend: 'up' 
          },
          { 
            name: settings.language === 'th' ? 'สังคมศึกษา' : settings.language === 'en' ? 'Social Studies' : '社会研究', 
            grade: 88, 
            trend: 'stable' 
          },
          { 
            name: settings.language === 'th' ? 'ภาษาอังกฤษ' : settings.language === 'en' ? 'English' : '英语', 
            grade: 89, 
            trend: 'up' 
          }
        ],
        attendance: 98,
        participation: 95
      },
      behavioral: {
        discipline: 85,
        cooperation: 88,
        leadership: 95,
        creativity: 90,
        responsibility: 87
      },
      recommendations: {
        teaching: settings.language === 'th' ?
          ['ใช้กิจกรรมที่ต้องลงมือทำจริง', 'ให้โอกาสเป็นผู้นำกลุ่ม', 'สร้างบทเรียนที่มีความท้าทาย'] :
          settings.language === 'en' ?
          ['Use hands-on activities', 'Provide opportunities to lead groups', 'Create challenging lessons'] :
          ['使用动手实践活动', '提供领导小组的机会', '创建具有挑战性的课程'],
        support: settings.language === 'th' ?
          ['ช่วยพัฒนาความอดทน', 'สอนการวางแผนและการจัดการเวลา', 'ส่งเสริมการทำงานร่วมกับผู้อื่น'] :
          settings.language === 'en' ?
          ['Help develop patience', 'Teach planning and time management', 'Encourage working with others'] :
          ['帮助培养耐心', '教授规划和时间管理', '鼓励与他人合作'],
        development: settings.language === 'th' ?
          ['พัฒนาทักษะการฟังผู้อื่น', 'เสริมสร้างความอดทนและความละเอียด', 'ฝึกการควบคุมอารมณ์'] :
          settings.language === 'en' ?
          ['Develop listening skills', 'Build patience and attention to detail', 'Practice emotional control'] :
          ['发展倾听技能', '培养耐心和细节关注', '练习情绪控制']
      },
      notes: [
        {
          date: '2024-01-12',
          content: settings.language === 'th' ? 
            'นักเรียนมีความสามารถโดดเด่นในวิชาคณิตศาสตร์ ควรส่งเสริมให้เข้าร่วมการแข่งขัน' :
            settings.language === 'en' ? 
            'Student excels in mathematics. Should encourage participation in competitions' :
            '学生在数学方面表现出色。应鼓励参加比赛',
          type: 'academic'
        }
      ],
      progressData: [
        { month: settings.language === 'th' ? 'ส.ค.' : settings.language === 'en' ? 'Aug' : '8月', score: 88 },
        { month: settings.language === 'th' ? 'ก.ย.' : settings.language === 'en' ? 'Sep' : '9月', score: 89 },
        { month: settings.language === 'th' ? 'ต.ค.' : settings.language === 'en' ? 'Oct' : '10月', score: 90 },
        { month: settings.language === 'th' ? 'พ.ย.' : settings.language === 'en' ? 'Nov' : '11月', score: 91 },
        { month: settings.language === 'th' ? 'ธ.ค.' : settings.language === 'en' ? 'Dec' : '12月', score: 91 },
        { month: settings.language === 'th' ? 'ม.ค.' : settings.language === 'en' ? 'Jan' : '1月', score: 91 }
      ]
    }
  ]);

  const selectedStudentData = students.find(s => s.id === selectedStudent);

  const radarData = selectedStudentData ? [
    { 
      subject: settings.language === 'th' ? 'วินัย' : settings.language === 'en' ? 'Discipline' : '纪律', 
      value: selectedStudentData.behavioral.discipline 
    },
    { 
      subject: settings.language === 'th' ? 'ความร่วมมือ' : settings.language === 'en' ? 'Cooperation' : '合作', 
      value: selectedStudentData.behavioral.cooperation 
    },
    { 
      subject: settings.language === 'th' ? 'ภาวะผู้นำ' : settings.language === 'en' ? 'Leadership' : '领导力', 
      value: selectedStudentData.behavioral.leadership 
    },
    { 
      subject: settings.language === 'th' ? 'ความคิดสร้างสรรค์' : settings.language === 'en' ? 'Creativity' : '创造力', 
      value: selectedStudentData.behavioral.creativity 
    },
    { 
      subject: settings.language === 'th' ? 'ความรับผิดชอบ' : settings.language === 'en' ? 'Responsibility' : '责任感', 
      value: selectedStudentData.behavioral.responsibility 
    }
  ] : [];

  const getGradeColor = (grade: number) => {
    if (grade >= 90) return 'text-green-600 bg-green-100 dark:text-green-400 dark:bg-green-900/30';
    if (grade >= 80) return 'text-blue-600 bg-blue-100 dark:text-blue-400 dark:bg-blue-900/30';
    if (grade >= 70) return 'text-yellow-600 bg-yellow-100 dark:text-yellow-400 dark:bg-yellow-900/30';
    if (grade >= 60) return 'text-orange-600 bg-orange-100 dark:text-orange-400 dark:bg-orange-900/30';
    return 'text-red-600 bg-red-100 dark:text-red-400 dark:bg-red-900/30';
  };

  const getGradeLabel = (grade: number) => {
    if (grade >= 90) return settings.language === 'th' ? 'ดีเยี่ยม' : settings.language === 'en' ? 'Excellent' : '优秀';
    if (grade >= 80) return settings.language === 'th' ? 'ดี' : settings.language === 'en' ? 'Good' : '良好';
    if (grade >= 70) return settings.language === 'th' ? 'ปานกลาง' : settings.language === 'en' ? 'Fair' : '一般';
    if (grade >= 60) return settings.language === 'th' ? 'พอใช้' : settings.language === 'en' ? 'Satisfactory' : '及格';
    return settings.language === 'th' ? 'ต้องปรับปรุง' : settings.language === 'en' ? 'Needs Improvement' : '需要改进';
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-600 dark:text-green-400" />;
      case 'down': return <TrendingUp className="h-4 w-4 text-red-600 dark:text-red-400 transform rotate-180" />;
      default: return <Activity className="h-4 w-4 text-gray-600 dark:text-gray-400" />;
    }
  };

  const handleAddNote = () => {
    if (!selectedStudentData || !newNote.content) return;
    
    const updatedStudents = students.map(student => {
      if (student.id === selectedStudent) {
        return {
          ...student,
          notes: [
            ...student.notes,
            {
              date: new Date().toISOString().split('T')[0],
              content: newNote.content,
              type: newNote.type
            }
          ]
        };
      }
      return student;
    });
    
    setStudents(updatedStudents);
    setNewNote({ content: '', type: 'academic' });
    setShowAddNoteModal(false);
  };

  const handleAddStudent = () => {
    if (!newStudent.name || !newStudent.studentId) return;
    
    const newStudentProfile: StudentProfile = {
      id: Date.now().toString(),
      name: newStudent.name,
      studentId: newStudent.studentId,
      grade: newStudent.grade,
      photo: newStudent.photo,
      personality: {
        learningStyle: settings.language === 'th' ? 'ยังไม่ได้ระบุ' : 
                       settings.language === 'en' ? 'Not specified yet' : 
                       '尚未指定',
        strengths: [],
        challenges: [],
        motivation: settings.language === 'th' ? 'ยังไม่ได้ระบุ' : 
                    settings.language === 'en' ? 'Not specified yet' : 
                    '尚未指定',
        socialStyle: settings.language === 'th' ? 'ยังไม่ได้ระบุ' : 
                     settings.language === 'en' ? 'Not specified yet' : 
                     '尚未指定'
      },
      academic: {
        overallGrade: 0,
        subjects: [],
        attendance: 0,
        participation: 0
      },
      behavioral: {
        discipline: 0,
        cooperation: 0,
        leadership: 0,
        creativity: 0,
        responsibility: 0
      },
      recommendations: {
        teaching: [],
        support: [],
        development: []
      },
      notes: [],
      progressData: []
    };
    
    setStudents([...students, newStudentProfile]);
    setNewStudent({
      name: '',
      studentId: '',
      grade: settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班',
      photo: 'https://images.pexels.com/photos/1462630/pexels-photo-1462630.jpeg'
    });
    setShowAddStudentModal(false);
    
    // Select the newly added student
    setSelectedStudent(newStudentProfile.id);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="mb-8">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-2 flex items-center">
          <User className="h-8 w-8 mr-3 text-indigo-600 dark:text-indigo-400" />
          {t('pages.studentProfiles.title')}
        </h2>
        <p className="text-gray-600 dark:text-gray-300">{t('pages.studentProfiles.description')}</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Student List */}
        <div className="lg:col-span-1">
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {settings.language === 'th' ? 'เลือกนักเรียน' : 
                 settings.language === 'en' ? 'Select Student' : 
                 '选择学生'}
              </h3>
              <button
                onClick={() => setShowAddStudentModal(true)}
                className="p-1 text-indigo-600 hover:text-indigo-800 dark:text-indigo-400 dark:hover:text-indigo-300"
                title={settings.language === 'th' ? 'เพิ่มนักเรียนใหม่' : 
                      settings.language === 'en' ? 'Add new student' : 
                      '添加新学生'}
              >
                <Plus className="h-5 w-5" />
              </button>
            </div>
            <div className="space-y-3">
              {students.map((student) => (
                <div
                  key={student.id}
                  onClick={() => setSelectedStudent(student.id)}
                  className={`p-3 rounded-lg cursor-pointer transition-colors ${
                    selectedStudent === student.id
                      ? 'bg-indigo-50 dark:bg-indigo-900/30 border-2 border-indigo-200 dark:border-indigo-700'
                      : 'bg-gray-50 dark:bg-gray-700 hover:bg-gray-100 dark:hover:bg-gray-600 border-2 border-transparent'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <img 
                      src={student.photo} 
                      alt={student.name}
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900 dark:text-white">{student.name}</p>
                      <p className="text-xs text-gray-500 dark:text-gray-400">{student.studentId} • {student.grade}</p>
                      <div className="flex items-center mt-1">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(student.academic.overallGrade)}`}>
                          {student.academic.overallGrade}%
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Student Details */}
        <div className="lg:col-span-3">
          {selectedStudentData ? (
            <div className="space-y-6">
              {/* Student Header */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-6">
                <div className="flex items-center space-x-6">
                  <img 
                    src={selectedStudentData.photo} 
                    alt={selectedStudentData.name}
                    className="w-20 h-20 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold text-gray-900 dark:text-white">{selectedStudentData.name}</h3>
                    <p className="text-gray-600 dark:text-gray-300">{selectedStudentData.studentId} • {selectedStudentData.grade}</p>
                    <div className="flex items-center mt-2 space-x-4">
                      <span className={`px-3 py-1 rounded-full text-sm font-medium ${getGradeColor(selectedStudentData.academic.overallGrade)}`}>
                        {settings.language === 'th' ? 'เกรดรวม:' : 
                         settings.language === 'en' ? 'Overall Grade:' : 
                         '总成绩:'} {selectedStudentData.academic.overallGrade}%
                      </span>
                      <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300 rounded-full text-sm">
                        {settings.language === 'th' ? 'เข้าเรียน:' : 
                         settings.language === 'en' ? 'Attendance:' : 
                         '出勤率:'} {selectedStudentData.academic.attendance}%
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Tabs */}
              <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700">
                <div className="border-b border-gray-200 dark:border-gray-700">
                  <nav className="flex space-x-8 px-6">
                    {[
                      { 
                        id: 'overview', 
                        label: settings.language === 'th' ? 'ภาพรวม' : 
                                settings.language === 'en' ? 'Overview' : 
                                '概览', 
                        icon: BarChart3 
                      },
                      { 
                        id: 'personality', 
                        label: settings.language === 'th' ? 'บุคลิกภาพ' : 
                                settings.language === 'en' ? 'Personality' : 
                                '个性', 
                        icon: Brain 
                      },
                      { 
                        id: 'academic', 
                        label: settings.language === 'th' ? 'ผลการเรียน' : 
                                settings.language === 'en' ? 'Academic' : 
                                '学业', 
                        icon: BookOpen 
                      },
                      { 
                        id: 'behavior', 
                        label: settings.language === 'th' ? 'พฤติกรรม' : 
                                settings.language === 'en' ? 'Behavior' : 
                                '行为', 
                        icon: Heart 
                      },
                      { 
                        id: 'recommendations', 
                        label: settings.language === 'th' ? 'คำแนะนำ' : 
                                settings.language === 'en' ? 'Recommendations' : 
                                '建议', 
                        icon: Lightbulb 
                      },
                      { 
                        id: 'notes', 
                        label: settings.language === 'th' ? 'บันทึก' : 
                                settings.language === 'en' ? 'Notes' : 
                                '笔记', 
                        icon: FileText 
                      }
                    ].map((tab) => (
                      <button
                        key={tab.id}
                        onClick={() => setActiveTab(tab.id)}
                        className={`py-4 px-1 border-b-2 font-medium text-sm flex items-center ${
                          activeTab === tab.id
                            ? 'border-indigo-500 text-indigo-600 dark:text-indigo-400'
                            : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-300 hover:border-gray-300 dark:hover:border-gray-600'
                        }`}
                      >
                        <tab.icon className="h-4 w-4 mr-2" />
                        {tab.label}
                      </button>
                    ))}
                  </nav>
                </div>

                <div className="p-6">
                  {/* Overview Tab */}
                  {activeTab === 'overview' && (
                    <div className="space-y-6">
                      {/* Progress Chart */}
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                          {settings.language === 'th' ? 'แนวโน้มผลการเรียน' : 
                           settings.language === 'en' ? 'Learning Progress Trend' : 
                           '学习进度趋势'}
                        </h4>
                        <div className="h-64">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={selectedStudentData.progressData}>
                              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
                              <XAxis dataKey="month" stroke="#9ca3af" />
                              <YAxis domain={[0, 100]} stroke="#9ca3af" />
                              <Tooltip contentStyle={{ backgroundColor: '#1f2937', borderColor: '#374151', color: '#f9fafb' }} />
                              <Line type="monotone" dataKey="score" stroke="#4F46E5" strokeWidth={2} />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>

                      {/* Subject Performance */}
                      <div>
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                          {settings.language === 'th' ? 'ผลการเรียนรายวิชา' : 
                           settings.language === 'en' ? 'Subject Performance' : 
                           '各科目表现'}
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                          {selectedStudentData.academic.subjects.map((subject, index) => (
                            <div key={index} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
                              <div className="flex items-center justify-between mb-2">
                                <h5 className="font-medium text-gray-900 dark:text-white">{subject.name}</h5>
                                {getTrendIcon(subject.trend)}
                              </div>
                              <div className="flex items-center justify-between">
                                <span className="text-2xl font-bold text-gray-900 dark:text-white">{subject.grade}%</span>
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(subject.grade)}`}>
                                  {getGradeLabel(subject.grade)}
                                </span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Personality Tab */}
                  {activeTab === 'personality' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6">
                          <h4 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-3 flex items-center">
                            <Brain className="h-5 w-5 mr-2" />
                            {settings.language === 'th' ? 'รูปแบบการเรียนรู้' : 
                             settings.language === 'en' ? 'Learning Style' : 
                             '学习风格'}
                          </h4>
                          <p className="text-blue-800 dark:text-blue-200">{selectedStudentData.personality.learningStyle}</p>
                        </div>

                        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6">
                          <h4 className="text-lg font-semibold text-green-900 dark:text-green-100 mb-3 flex items-center">
                            <Heart className="h-5 w-5 mr-2" />
                            {settings.language === 'th' ? 'แรงจูงใจ' : 
                             settings.language === 'en' ? 'Motivation' : 
                             '动机'}
                          </h4>
                          <p className="text-green-800 dark:text-green-200">{selectedStudentData.personality.motivation}</p>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                            <CheckCircle className="h-5 w-5 mr-2 text-green-600 dark:text-green-400" />
                            {settings.language === 'th' ? 'จุดแข็ง' : 
                             settings.language === 'en' ? 'Strengths' : 
                             '优势'}
                          </h4>
                          <ul className="space-y-2">
                            {selectedStudentData.personality.strengths.map((strength, index) => (
                              <li key={index} className="flex items-center text-gray-700 dark:text-gray-300">
                                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400 mr-2" />
                                {strength}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-3 flex items-center">
                            <AlertTriangle className="h-5 w-5 mr-2 text-orange-600 dark:text-orange-400" />
                            {settings.language === 'th' ? 'จุดที่ต้องพัฒนา' : 
                             settings.language === 'en' ? 'Areas for Development' : 
                             '需要发展的方面'}
                          </h4>
                          <ul className="space-y-2">
                            {selectedStudentData.personality.challenges.map((challenge, index) => (
                              <li key={index} className="flex items-center text-gray-700 dark:text-gray-300">
                                <AlertTriangle className="h-4 w-4 text-orange-600 dark:text-orange-400 mr-2" />
                                {challenge}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6">
                        <h4 className="text-lg font-semibold text-purple-900 dark:text-purple-100 mb-3 flex items-center">
                          <Users className="h-5 w-5 mr-2" />
                          {settings.language === 'th' ? 'ลักษณะทางสังคม' : 
                           settings.language === 'en' ? 'Social Characteristics' : 
                           '社交特点'}
                        </h4>
                        <p className="text-purple-800 dark:text-purple-200">{selectedStudentData.personality.socialStyle}</p>
                      </div>
                    </div>
                  )}

                  {/* Academic Tab */}
                  {activeTab === 'academic' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="bg-indigo-50 dark:bg-indigo-900/20 rounded-lg p-6 text-center">
                          <Award className="h-8 w-8 text-indigo-600 dark:text-indigo-400 mx-auto mb-2" />
                          <div className="text-2xl font-bold text-indigo-900 dark:text-indigo-100">{selectedStudentData.academic.overallGrade}%</div>
                          <div className="text-sm text-indigo-700 dark:text-indigo-300">
                            {settings.language === 'th' ? 'เกรดรวม' : 
                             settings.language === 'en' ? 'Overall Grade' : 
                             '总成绩'}
                          </div>
                        </div>
                        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6 text-center">
                          <Clock className="h-8 w-8 text-green-600 dark:text-green-400 mx-auto mb-2" />
                          <div className="text-2xl font-bold text-green-900 dark:text-green-100">{selectedStudentData.academic.attendance}%</div>
                          <div className="text-sm text-green-700 dark:text-green-300">
                            {settings.language === 'th' ? 'การเข้าเรียน' : 
                             settings.language === 'en' ? 'Attendance' : 
                             '出勤率'}
                          </div>
                        </div>
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6 text-center">
                          <Users className="h-8 w-8 text-blue-600 dark:text-blue-400 mx-auto mb-2" />
                          <div className="text-2xl font-bold text-blue-900 dark:text-blue-100">{selectedStudentData.academic.participation}%</div>
                          <div className="text-sm text-blue-700 dark:text-blue-300">
                            {settings.language === 'th' ? 'การมีส่วนร่วม' : 
                             settings.language === 'en' ? 'Participation' : 
                             '参与度'}
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                          {settings.language === 'th' ? 'รายละเอียดผลการเรียนรายวิชา' : 
                           settings.language === 'en' ? 'Detailed Subject Performance' : 
                           '详细科目表现'}
                        </h4>
                        <div className="overflow-x-auto">
                          <table className="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                            <thead className="bg-gray-50 dark:bg-gray-700">
                              <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                  {settings.language === 'th' ? 'วิชา' : 
                                   settings.language === 'en' ? 'Subject' : 
                                   '科目'}
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                  {settings.language === 'th' ? 'คะแนน' : 
                                   settings.language === 'en' ? 'Score' : 
                                   '分数'}
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                  {settings.language === 'th' ? 'เกรด' : 
                                   settings.language === 'en' ? 'Grade' : 
                                   '等级'}
                                </th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase tracking-wider">
                                  {settings.language === 'th' ? 'แนวโน้ม' : 
                                   settings.language === 'en' ? 'Trend' : 
                                   '趋势'}
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                              {selectedStudentData.academic.subjects.map((subject, index) => (
                                <tr key={index}>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900 dark:text-white">{subject.name}</td>
                                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">{subject.grade}%</td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${getGradeColor(subject.grade)}`}>
                                      {subject.grade >= 90 ? 'A' : subject.grade >= 80 ? 'B' : subject.grade >= 70 ? 'C' : subject.grade >= 60 ? 'D' : 'F'}
                                    </span>
                                  </td>
                                  <td className="px-6 py-4 whitespace-nowrap">
                                    {getTrendIcon(subject.trend)}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Behavior Tab */}
                  {activeTab === 'behavior' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div>
                          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                            {settings.language === 'th' ? 'คะแนนพฤติกรรม' : 
                             settings.language === 'en' ? 'Behavior Scores' : 
                             '行为评分'}
                          </h4>
                          <div className="space-y-4">
                            {[
                              { 
                                label: settings.language === 'th' ? 'วินัย' : settings.language === 'en' ? 'Discipline' : '纪律', 
                                value: selectedStudentData.behavioral.discipline, 
                                color: 'blue' 
                              },
                              { 
                                label: settings.language === 'th' ? 'ความร่วมมือ' : settings.language === 'en' ? 'Cooperation' : '合作', 
                                value: selectedStudentData.behavioral.cooperation, 
                                color: 'green' 
                              },
                              { 
                                label: settings.language === 'th' ? 'ภาวะผู้นำ' : settings.language === 'en' ? 'Leadership' : '领导力', 
                                value: selectedStudentData.behavioral.leadership, 
                                color: 'purple' 
                              },
                              { 
                                label: settings.language === 'th' ? 'ความคิดสร้างสรรค์' : settings.language === 'en' ? 'Creativity' : '创造力', 
                                value: selectedStudentData.behavioral.creativity, 
                                color: 'yellow' 
                              },
                              { 
                                label: settings.language === 'th' ? 'ความรับผิดชอบ' : settings.language === 'en' ? 'Responsibility' : '责任感', 
                                value: selectedStudentData.behavioral.responsibility, 
                                color: 'red' 
                              }
                            ].map((item, index) => (
                              <div key={index} className="flex items-center justify-between">
                                <span className="text-sm font-medium text-gray-700 dark:text-gray-300">{item.label}</span>
                                <div className="flex items-center space-x-2">
                                  <div className="w-32 bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                                    <div 
                                      className={`bg-${item.color}-600 dark:bg-${item.color}-500 h-2 rounded-full`}
                                      style={{ width: `${item.value}%` }}
                                    ></div>
                                  </div>
                                  <span className="text-sm font-bold text-gray-900 dark:text-white w-8">{item.value}</span>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
                            {settings.language === 'th' ? 'แผนภูมิเรดาร์พฤติกรรม' : 
                             settings.language === 'en' ? 'Behavior Radar Chart' : 
                             '行为雷达图'}
                          </h4>
                          <div className="h-64">
                            <ResponsiveContainer width="100%" height="100%">
                              <RadarChart data={radarData}>
                                <PolarGrid stroke="#374151" />
                                <PolarAngleAxis dataKey="subject" stroke="#9ca3af" />
                                <PolarRadiusAxis angle={90} domain={[0, 100]} stroke="#9ca3af" />
                                <Radar name="Score" dataKey="value" stroke="#4F46E5" fill="#4F46E5" fillOpacity={0.3} />
                              </RadarChart>
                            </ResponsiveContainer>
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Recommendations Tab */}
                  {activeTab === 'recommendations' && (
                    <div className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="bg-blue-50 dark:bg-blue-900/20 rounded-lg p-6">
                          <h4 className="text-lg font-semibold text-blue-900 dark:text-blue-100 mb-4 flex items-center">
                            <BookOpen className="h-5 w-5 mr-2" />
                            {settings.language === 'th' ? 'วิธีการสอน' : 
                             settings.language === 'en' ? 'Teaching Methods' : 
                             '教学方法'}
                          </h4>
                          <ul className="space-y-2">
                            {selectedStudentData.recommendations.teaching.map((item, index) => (
                              <li key={index} className="flex items-start text-blue-800 dark:text-blue-200">
                                <Target className="h-4 w-4 text-blue-600 dark:text-blue-400 mr-2 mt-0.5 flex-shrink-0" />
                                <span className="text-sm">{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-green-50 dark:bg-green-900/20 rounded-lg p-6">
                          <h4 className="text-lg font-semibold text-green-900 dark:text-green-100 mb-4 flex items-center">
                            <Heart className="h-5 w-5 mr-2" />
                            {settings.language === 'th' ? 'การสนับสนุน' : 
                             settings.language === 'en' ? 'Support' : 
                             '支持'}
                          </h4>
                          <ul className="space-y-2">
                            {selectedStudentData.recommendations.support.map((item, index) => (
                              <li key={index} className="flex items-start text-green-800 dark:text-green-200">
                                <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                                <span className="text-sm">{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div className="bg-purple-50 dark:bg-purple-900/20 rounded-lg p-6">
                          <h4 className="text-lg font-semibold text-purple-900 dark:text-purple-100 mb-4 flex items-center">
                            <TrendingUp className="h-5 w-5 mr-2" />
                            {settings.language === 'th' ? 'การพัฒนา' : 
                             settings.language === 'en' ? 'Development' : 
                             '发展'}
                          </h4>
                          <ul className="space-y-2">
                            {selectedStudentData.recommendations.development.map((item, index) => (
                              <li key={index} className="flex items-start text-purple-800 dark:text-purple-200">
                                <Lightbulb className="h-4 w-4 text-purple-600 dark:text-purple-400 mr-2 mt-0.5 flex-shrink-0" />
                                <span className="text-sm">{item}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Notes Tab */}
                  {activeTab === 'notes' && (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <h4 className="text-lg font-semibold text-gray-900 dark:text-white">
                          {settings.language === 'th' ? 'บันทึกการสังเกต' : 
                           settings.language === 'en' ? 'Observation Notes' : 
                           '观察笔记'}
                        </h4>
                        <button 
                          onClick={() => setShowAddNoteModal(true)}
                          className="px-4 py-2 bg-indigo-600 dark:bg-indigo-500 text-white rounded-md hover:bg-indigo-700 dark:hover:bg-indigo-600 transition-colors"
                        >
                          {settings.language === 'th' ? 'เพิ่มบันทึกใหม่' : 
                           settings.language === 'en' ? 'Add New Note' : 
                           '添加新笔记'}
                        </button>
                      </div>

                      <div className="space-y-4">
                        {selectedStudentData.notes.length > 0 ? (
                          selectedStudentData.notes.map((note, index) => (
                            <div key={index} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4 border-l-4 border-indigo-500 dark:border-indigo-400">
                              <div className="flex items-center justify-between mb-2">
                                <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                                  note.type === 'academic' ? 'bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300' :
                                  note.type === 'behavioral' ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300' :
                                  'bg-purple-100 dark:bg-purple-900/30 text-purple-800 dark:text-purple-300'
                                }`}>
                                  {note.type === 'academic' ? 
                                    (settings.language === 'th' ? 'วิชาการ' : 
                                     settings.language === 'en' ? 'Academic' : 
                                     '学术') : 
                                   note.type === 'behavioral' ? 
                                    (settings.language === 'th' ? 'พฤติกรรม' : 
                                     settings.language === 'en' ? 'Behavioral' : 
                                     '行为') : 
                                    (settings.language === 'th' ? 'ส่วนตัว' : 
                                     settings.language === 'en' ? 'Personal' : 
                                     '个人')}
                                </span>
                                <span className="text-xs text-gray-500 dark:text-gray-400">{note.date}</span>
                              </div>
                              <p className="text-gray-700 dark:text-gray-300">{note.content}</p>
                            </div>
                          ))
                        ) : (
                          <div className="text-center py-8">
                            <FileText className="h-12 w-12 text-gray-300 dark:text-gray-600 mx-auto mb-3" />
                            <p className="text-gray-500 dark:text-gray-400">
                              {settings.language === 'th' ? 'ยังไม่มีบันทึก คลิกปุ่ม "เพิ่มบันทึกใหม่" เพื่อเริ่มต้น' : 
                               settings.language === 'en' ? 'No notes yet. Click "Add New Note" to get started' : 
                               '暂无笔记。点击"添加新笔记"开始'}
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-12 text-center">
              <User className="h-16 w-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                {settings.language === 'th' ? 'เลือกนักเรียน' : 
                 settings.language === 'en' ? 'Select a Student' : 
                 '选择学生'}
              </h3>
              <p className="text-gray-600 dark:text-gray-300">
                {settings.language === 'th' ? 'กรุณาเลือกนักเรียนจากรายชื่อด้านซ้ายเพื่อดูโปรไฟล์รายละเอียด' : 
                 settings.language === 'en' ? 'Please select a student from the list on the left to view detailed profile' : 
                 '请从左侧列表中选择学生以查看详细资料'}
              </p>
              <button
                onClick={() => setShowAddStudentModal(true)}
                className="mt-4 px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors inline-flex items-center"
              >
                <Plus className="h-4 w-4 mr-2" />
                {settings.language === 'th' ? 'เพิ่มนักเรียนใหม่' : 
                 settings.language === 'en' ? 'Add New Student' : 
                 '添加新学生'}
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Add Note Modal */}
      {showAddNoteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {settings.language === 'th' ? 'เพิ่มบันทึกใหม่' : 
                   settings.language === 'en' ? 'Add New Note' : 
                   '添加新笔记'}
                </h3>
                <button
                  onClick={() => setShowAddNoteModal(false)}
                  className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {settings.language === 'th' ? 'ประเภท' : 
                     settings.language === 'en' ? 'Type' : 
                     '类型'}
                  </label>
                  <select
                    value={newNote.type}
                    onChange={(e) => setNewNote(prev => ({ ...prev, type: e.target.value as any }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value="academic">
                      {settings.language === 'th' ? 'วิชาการ' : 
                       settings.language === 'en' ? 'Academic' : 
                       '学术'}
                    </option>
                    <option value="behavioral">
                      {settings.language === 'th' ? 'พฤติกรรม' : 
                       settings.language === 'en' ? 'Behavioral' : 
                       '行为'}
                    </option>
                    <option value="personal">
                      {settings.language === 'th' ? 'ส่วนตัว' : 
                       settings.language === 'en' ? 'Personal' : 
                       '个人'}
                    </option>
                  </select>
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {settings.language === 'th' ? 'เนื้อหา' : 
                     settings.language === 'en' ? 'Content' : 
                     '内容'}
                  </label>
                  <textarea
                    value={newNote.content}
                    onChange={(e) => setNewNote(prev => ({ ...prev, content: e.target.value }))}
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                    placeholder={settings.language === 'th' ? 'พิมพ์บันทึกของคุณที่นี่...' : 
                                settings.language === 'en' ? 'Type your note here...' : 
                                '在此处输入您的笔记...'}
                  />
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setShowAddNoteModal(false)}
                  className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {settings.language === 'th' ? 'ยกเลิก' : 
                   settings.language === 'en' ? 'Cancel' : 
                   '取消'}
                </button>
                <button
                  onClick={handleAddNote}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                >
                  {settings.language === 'th' ? 'บันทึก' : 
                   settings.language === 'en' ? 'Save' : 
                   '保存'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add Student Modal */}
      {showAddStudentModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white dark:bg-gray-800 rounded-lg max-w-md w-full">
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  {settings.language === 'th' ? 'เพิ่มนักเรียนใหม่' : 
                   settings.language === 'en' ? 'Add New Student' : 
                   '添加新学生'}
                </h3>
                <button
                  onClick={() => setShowAddStudentModal(false)}
                  className="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {settings.language === 'th' ? 'ชื่อ-นามสกุล' : 
                     settings.language === 'en' ? 'Full Name' : 
                     '姓名'}
                  </label>
                  <input
                    type="text"
                    value={newStudent.name}
                    onChange={(e) => setNewStudent(prev => ({ ...prev, name: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                    placeholder={settings.language === 'th' ? 'กรอกชื่อ-นามสกุล' : 
                                settings.language === 'en' ? 'Enter full name' : 
                                '输入姓名'}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {settings.language === 'th' ? 'รหัสนักเรียน' : 
                     settings.language === 'en' ? 'Student ID' : 
                     '学生ID'}
                  </label>
                  <input
                    type="text"
                    value={newStudent.studentId}
                    onChange={(e) => setNewStudent(prev => ({ ...prev, studentId: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                    placeholder={settings.language === 'th' ? 'กรอกรหัสนักเรียน' : 
                                settings.language === 'en' ? 'Enter student ID' : 
                                '输入学生ID'}
                  />
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    {settings.language === 'th' ? 'ชั้นเรียน' : 
                     settings.language === 'en' ? 'Grade/Class' : 
                     '年级/班级'}
                  </label>
                  <select
                    value={newStudent.grade}
                    onChange={(e) => setNewStudent(prev => ({ ...prev, grade: e.target.value }))}
                    className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-700 dark:text-white"
                  >
                    <option value={settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班'}>
                      {settings.language === 'th' ? 'ม.1/1' : settings.language === 'en' ? 'Grade 7/1' : '7年级1班'}
                    </option>
                    <option value={settings.language === 'th' ? 'ม.1/2' : settings.language === 'en' ? 'Grade 7/2' : '7年级2班'}>
                      {settings.language === 'th' ? 'ม.1/2' : settings.language === 'en' ? 'Grade 7/2' : '7年级2班'}
                    </option>
                    <option value={settings.language === 'th' ? 'ม.2/1' : settings.language === 'en' ? 'Grade 8/1' : '8年级1班'}>
                      {settings.language === 'th' ? 'ม.2/1' : settings.language === 'en' ? 'Grade 8/1' : '8年级1班'}
                    </option>
                    <option value={settings.language === 'th' ? 'ม.2/2' : settings.language === 'en' ? 'Grade 8/2' : '8年级2班'}>
                      {settings.language === 'th' ? 'ม.2/2' : settings.language === 'en' ? 'Grade 8/2' : '8年级2班'}
                    </option>
                  </select>
                </div>
              </div>
              
              <div className="mt-6 flex justify-end space-x-3">
                <button
                  onClick={() => setShowAddStudentModal(false)}
                  className="px-4 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-md hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
                >
                  {settings.language === 'th' ? 'ยกเลิก' : 
                   settings.language === 'en' ? 'Cancel' : 
                   '取消'}
                </button>
                <button
                  onClick={handleAddStudent}
                  className="px-4 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                >
                  {settings.language === 'th' ? 'บันทึก' : 
                   settings.language === 'en' ? 'Save' : 
                   '保存'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudentProfiles;