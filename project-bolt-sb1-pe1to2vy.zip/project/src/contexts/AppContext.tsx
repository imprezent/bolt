import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { supabase } from '../lib/supabase';
import type { User, AppSettings } from '../types';

interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  settings: AppSettings;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: any) => Promise<boolean>;
  logout: () => Promise<void>;
  updateUser: (userData: Partial<User>) => void;
  updateSettings: (newSettings: Partial<AppSettings>) => void;
  t: (key: string) => string;
  generateAIContent: (type: string, context?: any) => Promise<string>;
  saveLessonPlan: (lessonData: any) => Promise<boolean>;
  getLessonPlans: () => Promise<any[]>;
  updateLessonPlan: (id: string, lessonData: any) => Promise<boolean>;
  saveActivity: (activityData: any) => Promise<boolean>;
  getActivities: () => Promise<any[]>;
  updateActivity: (id: string, activityData: any) => Promise<boolean>;
  saveTest: (testData: any) => Promise<boolean>;
  getTests: () => Promise<any[]>;
  updateTest: (id: string, testData: any) => Promise<boolean>;
  saveStudent: (studentData: any) => Promise<boolean>;
  getStudents: () => Promise<any[]>;
  updateStudent: (id: string, studentData: any) => Promise<boolean>;
  deleteStudent: (id: string) => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const translations = {
  th: {
    // Navigation
    'nav.dashboard': 'แดชบอร์ด',
    'nav.lessonPlanner': 'วางแผนการสอน',
    'nav.activityDesigner': 'ออกแบบกิจกรรม',
    'nav.testBuilder': 'สร้างแบบทดสอบ',
    'nav.studentAssessment': 'ประเมินนักเรียน',
    'nav.studentProfiles': 'โปรไฟล์นักเรียน',
    'nav.teachingMethods': 'วิธีการสอน',
    'nav.teachingResources': 'สื่อการสอน',
    'nav.googleIntegrations': 'Google Integrations',
    'nav.performanceAnalytics': 'วิเคราะห์ผลการเรียน',

    // Dashboard
    'dashboard.welcome': 'ยินดีต้อนรับ',
    'dashboard.todayTasks': 'งานวันนี้',
    'dashboard.studentsWaiting': 'นักเรียนรอ',
    'dashboard.waitingAssessment': 'รอการประเมิน',
    'dashboard.lessonPlans': 'แผนการสอน',
    'dashboard.activities': 'กิจกรรม',
    'dashboard.tests': 'แบบทดสอบ',
    'dashboard.students': 'นักเรียน',
    'dashboard.recentActivities': 'กิจกรรมล่าสุด',
    'dashboard.upcomingTasks': 'งานที่จะมาถึง',
    'dashboard.quickActions': 'การดำเนินการด่วน',
    'dashboard.createNewLesson': 'สร้างแผนการสอนใหม่',
    'dashboard.createNewTest': 'สร้างแบบทดสอบใหม่',
    'dashboard.createNewActivity': 'สร้างกิจกรรมใหม่',

    // Calendar
    'calendar.title': 'ปฏิทิน',

    // Authentication
    'auth.login': 'เข้าสู่ระบบ',
    'auth.register': 'ลงทะเบียน',
    'auth.logout': 'ออกจากระบบ',
    'auth.email': 'อีเมล',
    'auth.password': 'รหัสผ่าน',
    'auth.confirmPassword': 'ยืนยันรหัสผ่าน',
    'auth.name': 'ชื่อ-นามสกุล',
    'auth.school': 'โรงเรียน',
    'auth.noAccount': 'ยังไม่มีบัญชี?',
    'auth.haveAccount': 'มีบัญชีแล้ว?',
    'auth.switchToRegister': 'ลงทะเบียน',
    'auth.switchToLogin': 'เข้าสู่ระบบ',

    // Demo
    'demo.account': 'บัญชีทดลอง:',
    'demo.email': 'อีเมล: teacher@school.com',
    'demo.password': 'รหัสผ่าน: password',

    // Settings
    'settings.title': 'การตั้งค่า',
    'settings.profile': 'โปรไฟล์',
    'settings.language': 'ภาษา',
    'settings.theme': 'ธีม',
    'settings.fontSize': 'ขนาดตัวอักษร',

    // Profile
    'profile.title': 'โปรไฟล์',
    'profile.edit': 'แก้ไข',
    'profile.bio': 'เกี่ยวกับฉัน',
    'profile.experience': 'ประสบการณ์',
    'profile.subjects': 'วิชาที่สอน',
    'profile.education': 'การศึกษา',
    'profile.certifications': 'ใบรับรอง',

    // Class
    'class.myClasses': 'ชั้นเรียนของฉัน',
    'class.viewAll': 'ดูทั้งหมด',
    'class.joinGoogleMeet': 'เข้าร่วม Google Meet',
    'class.openGoogleClassroom': 'เปิด Google Classroom',

    // Quick Actions
    'quickAction.createLesson': 'สร้างแผนการสอนใหม่',
    'quickAction.createTest': 'สร้างแบบทดสอบใหม่',
    'quickAction.createActivity': 'สร้างกิจกรรมใหม่',

    // Subjects
    'subject.thai': 'ภาษาไทย',
    'subject.math': 'คณิตศาสตร์',
    'subject.science': 'วิทยาศาสตร์',
    'subject.social': 'สังคมศึกษา',
    'subject.english': 'ภาษาอังกฤษ',
    'subject.art': 'ศิลปะ',
    'subject.pe': 'พลศึกษา',

    // Grades
    'grade.p1': 'ป.1',
    'grade.p2': 'ป.2',
    'grade.p3': 'ป.3',
    'grade.p4': 'ป.4',
    'grade.p5': 'ป.5',
    'grade.p6': 'ป.6',
    'grade.m1': 'ม.1',
    'grade.m2': 'ม.2',
    'grade.m3': 'ม.3',
    'grade.m4': 'ม.4',
    'grade.m5': 'ม.5',
    'grade.m6': 'ม.6',

    // Teaching Methods
    'teachingMethod.discussion': 'การสอนแบบอภิปราย',
    'teachingMethod.cooperative': 'การเรียนรู้แบบร่วมมือ',
    'teachingMethod.inquiry': 'การสอนแบบสืบเสาะ',
    'teachingMethod.project': 'การสอนแบบโครงงาน',
    'teachingMethod.game': 'การสอนผ่านเกม',
    'teachingMethod.interactive': 'การสอนเชิงปฏิสัมพันธ์',

    // Google Integration
    'google.forms': 'Google Forms',
    'google.classroom': 'Google Classroom',
    'google.drive': 'Google Drive',
    'google.calendar': 'Google Calendar',
    'google.connected': 'เชื่อมต่อแล้ว',
    'google.notConnected': 'ยังไม่ได้เชื่อมต่อ',
    'google.connect': 'เชื่อมต่อ',
    'google.disconnect': 'ยกเลิกการเชื่อมต่อ',
    'google.open': 'เปิด',

    // Common
    'common.save': 'บันทึก',
    'common.cancel': 'ยกเลิก',
    'common.edit': 'แก้ไข',
    'common.delete': 'ลบ',
    'common.view': 'ดู',
    'common.create': 'สร้าง',
    'common.update': 'อัปเดต',
    'common.search': 'ค้นหา',
    'common.filter': 'กรอง',
    'common.all': 'ทั้งหมด',
    'common.loading': 'กำลังโหลด...',
    'common.error': 'เกิดข้อผิดพลาด',
    'common.success': 'สำเร็จ',
    'common.close': 'ปิด',
    'common.preview': 'ดูตัวอย่าง',
    'common.download': 'ดาวน์โหลด',
    'common.share': 'แชร์',
    'common.print': 'พิมพ์',
    'common.export': 'ส่งออก',
    'common.import': 'นำเข้า',
    'common.refresh': 'รีเฟรช',
    'common.back': 'กลับ',
    'common.next': 'ถัดไป',
    'common.previous': 'ก่อนหน้า',
    'common.submit': 'ส่ง',
    'common.reset': 'รีเซ็ต',
    'common.clear': 'ล้าง',
    'common.select': 'เลือก',
    'common.confirm': 'ยืนยัน',
    'common.yes': 'ใช่',
    'common.no': 'ไม่',

    // AI
    'ai.help': 'ช่วยเหลือ AI',
    'ai.generating': 'กำลังสร้าง...',
    'ai.suggestions': 'คำแนะนำ AI',
    'ai.analysis': 'การวิเคราะห์ AI',
    'ai.recommendations': 'คำแนะนำ',

    // Pages
    'pages.lessonPlanner.title': 'วางแผนการสอน',
    'pages.lessonPlanner.description': 'สร้างและจัดการแผนการสอนด้วยความช่วยเหลือจาก AI',
    'pages.activityDesigner.title': 'ออกแบบกิจกรรม',
    'pages.activityDesigner.description': 'ออกแบบกิจกรรมการเรียนรู้ที่น่าสนใจและมีประสิทธิภาพ',
    'pages.testBuilder.title': 'สร้างแบบทดสอบ',
    'pages.testBuilder.description': 'สร้างแบบทดสอบที่หลากหลายและมีคุณภาพ',
    'pages.studentAssessment.title': 'ประเมินนักเรียน',
    'pages.studentAssessment.description': 'ประเมินและติดตามผลการเรียนของนักเรียน',
    'pages.studentProfiles.title': 'โปรไฟล์นักเรียน',
    'pages.studentProfiles.description': 'จัดการข้อมูลและโปรไฟล์ของนักเรียน',
    'pages.teachingMethods.title': 'วิธีการสอน',
    'pages.teachingMethods.description': 'เรียนรู้วิธีการสอนที่หลากหลายและมีประสิทธิภาพ',
    'pages.teachingResources.title': 'สื่อการสอน',
    'pages.teachingResources.description': 'ค้นหาและใช้สื่อการสอนที่มีคุณภาพ',
    'pages.performanceAnalytics.title': 'วิเคราะห์ผลการเรียน',
    'pages.performanceAnalytics.description': 'วิเคราะห์และติดตามผลการเรียนของนักเรียน',

    // Activity Designer
    'activityDesigner.aiSuggestions': 'คำแนะนำกิจกรรมจาก AI',
    'activityDesigner.generateActivity': 'สร้างกิจกรรม',

    // Test Builder
    'testBuilder.generateQuestions': 'สร้างคำถาม',
    'testBuilder.topic': 'หัวข้อ',
    'testBuilder.difficulty': 'ระดับความยาก',
    'testBuilder.questionType': 'ประเภทคำถาม',

    // Student Assessment
    'studentAssessment.aiAnalysis': 'วิเคราะห์ด้วย AI',
    'studentAssessment.recommendations': 'คำแนะนำ',

    // Student names and details
    'student.somjai': 'นางสาวสมใจ ใจดี',
    'student.somsak': 'นายสมศักดิ์ เรียนดี',
    'student.priya': 'นางสาวปรียา ขยันเรียน',

    // Difficulty levels
    'difficulty.easy': 'ง่าย',
    'difficulty.medium': 'ปานกลาง',
    'difficulty.hard': 'ยาก',

    // Time units
    'time.minutes': 'นาที',
    'time.hours': 'ชั่วโมง',
    'time.days': 'วัน',
    'time.weeks': 'สัปดาห์',
    'time.months': 'เดือน',

    // Status
    'status.excellent': 'ดีเยี่ยม',
    'status.good': 'ดี',
    'status.fair': 'ปานกลาง',
    'status.needsImprovement': 'ต้องปรับปรุง',

    // Form labels
    'form.title': 'ชื่อเรื่อง',
    'form.subject': 'วิชา',
    'form.grade': 'ระดับชั้น',
    'form.duration': 'ระยะเวลา',
    'form.category': 'หมวดหมู่',
    'form.type': 'ประเภท',
    'form.difficulty': 'ระดับความยาก',
    'form.topic': 'หัวข้อ',
    'form.learningStyle': 'รูปแบบการเรียนรู้',
    'form.questionCount': 'จำนวนคำถาม',

    // Buttons and Actions
    'button.createNew': 'สร้างใหม่',
    'button.viewAll': 'ดูทั้งหมด',
    'button.preview': 'ดูตัวอย่าง',
    'button.download': 'ดาวน์โหลด',
    'button.share': 'แชร์',
    'button.print': 'พิมพ์',
    'button.export': 'ส่งออก',
    'button.import': 'นำเข้า',

    // Messages
    'message.noData': 'ไม่มีข้อมูล',
    'message.noResults': 'ไม่พบผลลัพธ์',
    'message.saveSuccess': 'บันทึกสำเร็จ',
    'message.updateSuccess': 'อัปเดตสำเร็จ',
    'message.deleteSuccess': 'ลบสำเร็จ',
    'message.saveError': 'เกิดข้อผิดพลาดในการบันทึก',
    'message.updateError': 'เกิดข้อผิดพลาดในการอัปเดต',
    'message.deleteError': 'เกิดข้อผิดพลาดในการลบ',
    'message.confirmDelete': 'คุณแน่ใจหรือไม่ที่จะลบ?',
    'message.pleaseWait': 'กรุณารอสักครู่...',
    'message.processing': 'กำลังดำเนินการ...',

    // Placeholders
    'placeholder.search': 'ค้นหา...',
    'placeholder.enterText': 'กรอกข้อความ...',
    'placeholder.selectOption': 'เลือกตัวเลือก...',
    'placeholder.enterEmail': 'กรอกอีเมล...',
    'placeholder.enterPassword': 'กรอกรหัสผ่าน...',
    'placeholder.enterName': 'กรอกชื่อ...',
    'placeholder.enterSchool': 'กรอกชื่อโรงเรียน...',
  },
  en: {
    // Navigation
    'nav.dashboard': 'Dashboard',
    'nav.lessonPlanner': 'Lesson Planner',
    'nav.activityDesigner': 'Activity Designer',
    'nav.testBuilder': 'Test Builder',
    'nav.studentAssessment': 'Student Assessment',
    'nav.studentProfiles': 'Student Profiles',
    'nav.teachingMethods': 'Teaching Methods',
    'nav.teachingResources': 'Teaching Resources',
    'nav.googleIntegrations': 'Google Integrations',
    'nav.performanceAnalytics': 'Performance Analytics',

    // Dashboard
    'dashboard.welcome': 'Welcome',
    'dashboard.todayTasks': 'Today\'s tasks',
    'dashboard.studentsWaiting': 'students waiting',
    'dashboard.waitingAssessment': 'waiting for assessment',
    'dashboard.lessonPlans': 'Lesson Plans',
    'dashboard.activities': 'Activities',
    'dashboard.tests': 'Tests',
    'dashboard.students': 'Students',
    'dashboard.recentActivities': 'Recent Activities',
    'dashboard.upcomingTasks': 'Upcoming Tasks',
    'dashboard.quickActions': 'Quick Actions',
    'dashboard.createNewLesson': 'Create New Lesson',
    'dashboard.createNewTest': 'Create New Test',
    'dashboard.createNewActivity': 'Create New Activity',

    // Calendar
    'calendar.title': 'Calendar',

    // Authentication
    'auth.login': 'Login',
    'auth.register': 'Register',
    'auth.logout': 'Logout',
    'auth.email': 'Email',
    'auth.password': 'Password',
    'auth.confirmPassword': 'Confirm Password',
    'auth.name': 'Full Name',
    'auth.school': 'School',
    'auth.noAccount': 'Don\'t have an account?',
    'auth.haveAccount': 'Already have an account?',
    'auth.switchToRegister': 'Register',
    'auth.switchToLogin': 'Login',

    // Demo
    'demo.account': 'Demo Account:',
    'demo.email': 'Email: teacher@school.com',
    'demo.password': 'Password: password',

    // Settings
    'settings.title': 'Settings',
    'settings.profile': 'Profile',
    'settings.language': 'Language',
    'settings.theme': 'Theme',
    'settings.fontSize': 'Font Size',

    // Profile
    'profile.title': 'Profile',
    'profile.edit': 'Edit',
    'profile.bio': 'About Me',
    'profile.experience': 'Experience',
    'profile.subjects': 'Subjects',
    'profile.education': 'Education',
    'profile.certifications': 'Certifications',

    // Class
    'class.myClasses': 'My Classes',
    'class.viewAll': 'View All',
    'class.joinGoogleMeet': 'Join Google Meet',
    'class.openGoogleClassroom': 'Open Google Classroom',

    // Quick Actions
    'quickAction.createLesson': 'Create New Lesson',
    'quickAction.createTest': 'Create New Test',
    'quickAction.createActivity': 'Create New Activity',

    // Subjects
    'subject.thai': 'Thai Language',
    'subject.math': 'Mathematics',
    'subject.science': 'Science',
    'subject.social': 'Social Studies',
    'subject.english': 'English',
    'subject.art': 'Art',
    'subject.pe': 'Physical Education',

    // Grades
    'grade.p1': 'Grade 1',
    'grade.p2': 'Grade 2',
    'grade.p3': 'Grade 3',
    'grade.p4': 'Grade 4',
    'grade.p5': 'Grade 5',
    'grade.p6': 'Grade 6',
    'grade.m1': 'Grade 7',
    'grade.m2': 'Grade 8',
    'grade.m3': 'Grade 9',
    'grade.m4': 'Grade 10',
    'grade.m5': 'Grade 11',
    'grade.m6': 'Grade 12',

    // Teaching Methods
    'teachingMethod.discussion': 'Discussion Method',
    'teachingMethod.cooperative': 'Cooperative Learning',
    'teachingMethod.inquiry': 'Inquiry-Based Learning',
    'teachingMethod.project': 'Project-Based Learning',
    'teachingMethod.game': 'Game-Based Learning',
    'teachingMethod.interactive': 'Interactive Teaching',

    // Google Integration
    'google.forms': 'Google Forms',
    'google.classroom': 'Google Classroom',
    'google.drive': 'Google Drive',
    'google.calendar': 'Google Calendar',
    'google.connected': 'Connected',
    'google.notConnected': 'Not Connected',
    'google.connect': 'Connect',
    'google.disconnect': 'Disconnect',
    'google.open': 'Open',

    // Common
    'common.save': 'Save',
    'common.cancel': 'Cancel',
    'common.edit': 'Edit',
    'common.delete': 'Delete',
    'common.view': 'View',
    'common.create': 'Create',
    'common.update': 'Update',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.all': 'All',
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.close': 'Close',
    'common.preview': 'Preview',
    'common.download': 'Download',
    'common.share': 'Share',
    'common.print': 'Print',
    'common.export': 'Export',
    'common.import': 'Import',
    'common.refresh': 'Refresh',
    'common.back': 'Back',
    'common.next': 'Next',
    'common.previous': 'Previous',
    'common.submit': 'Submit',
    'common.reset': 'Reset',
    'common.clear': 'Clear',
    'common.select': 'Select',
    'common.confirm': 'Confirm',
    'common.yes': 'Yes',
    'common.no': 'No',

    // AI
    'ai.help': 'AI Help',
    'ai.generating': 'Generating...',
    'ai.suggestions': 'AI Suggestions',
    'ai.analysis': 'AI Analysis',
    'ai.recommendations': 'Recommendations',

    // Pages
    'pages.lessonPlanner.title': 'Lesson Planner',
    'pages.lessonPlanner.description': 'Create and manage lesson plans with AI assistance',
    'pages.activityDesigner.title': 'Activity Designer',
    'pages.activityDesigner.description': 'Design engaging and effective learning activities',
    'pages.testBuilder.title': 'Test Builder',
    'pages.testBuilder.description': 'Create diverse and quality assessments',
    'pages.studentAssessment.title': 'Student Assessment',
    'pages.studentAssessment.description': 'Assess and track student learning progress',
    'pages.studentProfiles.title': 'Student Profiles',
    'pages.studentProfiles.description': 'Manage student data and profiles',
    'pages.teachingMethods.title': 'Teaching Methods',
    'pages.teachingMethods.description': 'Learn diverse and effective teaching methods',
    'pages.teachingResources.title': 'Teaching Resources',
    'pages.teachingResources.description': 'Find and use quality teaching materials',
    'pages.performanceAnalytics.title': 'Performance Analytics',
    'pages.performanceAnalytics.description': 'Analyze and track student performance',

    // Activity Designer
    'activityDesigner.aiSuggestions': 'AI Activity Suggestions',
    'activityDesigner.generateActivity': 'Generate Activity',

    // Test Builder
    'testBuilder.generateQuestions': 'Generate Questions',
    'testBuilder.topic': 'Topic',
    'testBuilder.difficulty': 'Difficulty',
    'testBuilder.questionType': 'Question Type',

    // Student Assessment
    'studentAssessment.aiAnalysis': 'AI Analysis',
    'studentAssessment.recommendations': 'Recommendations',

    // Student names and details
    'student.somjai': 'Miss Somjai Jaidee',
    'student.somsak': 'Mr. Somsak Riandee',
    'student.priya': 'Miss Priya Kayan',

    // Difficulty levels
    'difficulty.easy': 'Easy',
    'difficulty.medium': 'Medium',
    'difficulty.hard': 'Hard',

    // Time units
    'time.minutes': 'minutes',
    'time.hours': 'hours',
    'time.days': 'days',
    'time.weeks': 'weeks',
    'time.months': 'months',

    // Status
    'status.excellent': 'Excellent',
    'status.good': 'Good',
    'status.fair': 'Fair',
    'status.needsImprovement': 'Needs Improvement',

    // Form labels
    'form.title': 'Title',
    'form.subject': 'Subject',
    'form.grade': 'Grade',
    'form.duration': 'Duration',
    'form.category': 'Category',
    'form.type': 'Type',
    'form.difficulty': 'Difficulty',
    'form.topic': 'Topic',
    'form.learningStyle': 'Learning Style',
    'form.questionCount': 'Question Count',

    // Buttons and Actions
    'button.createNew': 'Create New',
    'button.viewAll': 'View All',
    'button.preview': 'Preview',
    'button.download': 'Download',
    'button.share': 'Share',
    'button.print': 'Print',
    'button.export': 'Export',
    'button.import': 'Import',

    // Messages
    'message.noData': 'No data available',
    'message.noResults': 'No results found',
    'message.saveSuccess': 'Saved successfully',
    'message.updateSuccess': 'Updated successfully',
    'message.deleteSuccess': 'Deleted successfully',
    'message.saveError': 'Error saving data',
    'message.updateError': 'Error updating data',
    'message.deleteError': 'Error deleting data',
    'message.confirmDelete': 'Are you sure you want to delete?',
    'message.pleaseWait': 'Please wait...',
    'message.processing': 'Processing...',

    // Placeholders
    'placeholder.search': 'Search...',
    'placeholder.enterText': 'Enter text...',
    'placeholder.selectOption': 'Select option...',
    'placeholder.enterEmail': 'Enter email...',
    'placeholder.enterPassword': 'Enter password...',
    'placeholder.enterName': 'Enter name...',
    'placeholder.enterSchool': 'Enter school name...',
  },
  zh: {
    // Navigation
    'nav.dashboard': '仪表板',
    'nav.lessonPlanner': '课程规划',
    'nav.activityDesigner': '活动设计',
    'nav.testBuilder': '测试构建',
    'nav.studentAssessment': '学生评估',
    'nav.studentProfiles': '学生档案',
    'nav.teachingMethods': '教学方法',
    'nav.teachingResources': '教学资源',
    'nav.googleIntegrations': 'Google 集成',
    'nav.performanceAnalytics': '绩效分析',

    // Dashboard
    'dashboard.welcome': '欢迎',
    'dashboard.todayTasks': '今日任务',
    'dashboard.studentsWaiting': '学生等待',
    'dashboard.waitingAssessment': '等待评估',
    'dashboard.lessonPlans': '课程计划',
    'dashboard.activities': '活动',
    'dashboard.tests': '测试',
    'dashboard.students': '学生',
    'dashboard.recentActivities': '最近活动',
    'dashboard.upcomingTasks': '即将到来的任务',
    'dashboard.quickActions': '快速操作',
    'dashboard.createNewLesson': '创建新课程',
    'dashboard.createNewTest': '创建新测试',
    'dashboard.createNewActivity': '创建新活动',

    // Calendar
    'calendar.title': '日历',

    // Authentication
    'auth.login': '登录',
    'auth.register': '注册',
    'auth.logout': '登出',
    'auth.email': '邮箱',
    'auth.password': '密码',
    'auth.confirmPassword': '确认密码',
    'auth.name': '姓名',
    'auth.school': '学校',
    'auth.noAccount': '还没有账户？',
    'auth.haveAccount': '已有账户？',
    'auth.switchToRegister': '注册',
    'auth.switchToLogin': '登录',

    // Demo
    'demo.account': '演示账户：',
    'demo.email': '邮箱：teacher@school.com',
    'demo.password': '密码：password',

    // Settings
    'settings.title': '设置',
    'settings.profile': '个人资料',
    'settings.language': '语言',
    'settings.theme': '主题',
    'settings.fontSize': '字体大小',

    // Profile
    'profile.title': '个人资料',
    'profile.edit': '编辑',
    'profile.bio': '关于我',
    'profile.experience': '经验',
    'profile.subjects': '科目',
    'profile.education': '教育背景',
    'profile.certifications': '认证',

    // Class
    'class.myClasses': '我的班级',
    'class.viewAll': '查看全部',
    'class.joinGoogleMeet': '加入 Google Meet',
    'class.openGoogleClassroom': '打开 Google Classroom',

    // Quick Actions
    'quickAction.createLesson': '创建新课程',
    'quickAction.createTest': '创建新测试',
    'quickAction.createActivity': '创建新活动',

    // Subjects
    'subject.thai': '泰语',
    'subject.math': '数学',
    'subject.science': '科学',
    'subject.social': '社会研究',
    'subject.english': '英语',
    'subject.art': '艺术',
    'subject.pe': '体育',

    // Grades
    'grade.p1': '1年级',
    'grade.p2': '2年级',
    'grade.p3': '3年级',
    'grade.p4': '4年级',
    'grade.p5': '5年级',
    'grade.p6': '6年级',
    'grade.m1': '7年级',
    'grade.m2': '8年级',
    'grade.m3': '9年级',
    'grade.m4': '10年级',
    'grade.m5': '11年级',
    'grade.m6': '12年级',

    // Teaching Methods
    'teachingMethod.discussion': '讨论教学法',
    'teachingMethod.cooperative': '合作学习',
    'teachingMethod.inquiry': '探究式学习',
    'teachingMethod.project': '项目式学习',
    'teachingMethod.game': '游戏化学习',
    'teachingMethod.interactive': '互动教学',

    // Google Integration
    'google.forms': 'Google 表单',
    'google.classroom': 'Google 课堂',
    'google.drive': 'Google 云端硬盘',
    'google.calendar': 'Google 日历',
    'google.connected': '已连接',
    'google.notConnected': '未连接',
    'google.connect': '连接',
    'google.disconnect': '断开连接',
    'google.open': '打开',

    // Common
    'common.save': '保存',
    'common.cancel': '取消',
    'common.edit': '编辑',
    'common.delete': '删除',
    'common.view': '查看',
    'common.create': '创建',
    'common.update': '更新',
    'common.search': '搜索',
    'common.filter': '筛选',
    'common.all': '全部',
    'common.loading': '加载中...',
    'common.error': '错误',
    'common.success': '成功',
    'common.close': '关闭',
    'common.preview': '预览',
    'common.download': '下载',
    'common.share': '分享',
    'common.print': '打印',
    'common.export': '导出',
    'common.import': '导入',
    'common.refresh': '刷新',
    'common.back': '返回',
    'common.next': '下一个',
    'common.previous': '上一个',
    'common.submit': '提交',
    'common.reset': '重置',
    'common.clear': '清除',
    'common.select': '选择',
    'common.confirm': '确认',
    'common.yes': '是',
    'common.no': '否',

    // AI
    'ai.help': 'AI 帮助',
    'ai.generating': '生成中...',
    'ai.suggestions': 'AI 建议',
    'ai.analysis': 'AI 分析',
    'ai.recommendations': '推荐',

    // Pages
    'pages.lessonPlanner.title': '课程规划器',
    'pages.lessonPlanner.description': '使用 AI 辅助创建和管理课程计划',
    'pages.activityDesigner.title': '活动设计器',
    'pages.activityDesigner.description': '设计引人入胜且有效的学习活动',
    'pages.testBuilder.title': '测试构建器',
    'pages.testBuilder.description': '创建多样化和高质量的评估',
    'pages.studentAssessment.title': '学生评估',
    'pages.studentAssessment.description': '评估和跟踪学生学习进度',
    'pages.studentProfiles.title': '学生档案',
    'pages.studentProfiles.description': '管理学生数据和档案',
    'pages.teachingMethods.title': '教学方法',
    'pages.teachingMethods.description': '学习多样化和有效的教学方法',
    'pages.teachingResources.title': '教学资源',
    'pages.teachingResources.description': '查找和使用优质教学材料',
    'pages.performanceAnalytics.title': '绩效分析',
    'pages.performanceAnalytics.description': '分析和跟踪学生表现',

    // Activity Designer
    'activityDesigner.aiSuggestions': 'AI 活动建议',
    'activityDesigner.generateActivity': '生成活动',

    // Test Builder
    'testBuilder.generateQuestions': '生成问题',
    'testBuilder.topic': '主题',
    'testBuilder.difficulty': '难度',
    'testBuilder.questionType': '问题类型',

    // Student Assessment
    'studentAssessment.aiAnalysis': 'AI 分析',
    'studentAssessment.recommendations': '建议',

    // Student names and details
    'student.somjai': '颂猜小姐',
    'student.somsak': '颂萨先生',
    'student.priya': '普丽雅小姐',

    // Difficulty levels
    'difficulty.easy': '简单',
    'difficulty.medium': '中等',
    'difficulty.hard': '困难',

    // Time units
    'time.minutes': '分钟',
    'time.hours': '小时',
    'time.days': '天',
    'time.weeks': '周',
    'time.months': '月',

    // Status
    'status.excellent': '优秀',
    'status.good': '良好',
    'status.fair': '一般',
    'status.needsImprovement': '需要改进',

    // Form labels
    'form.title': '标题',
    'form.subject': '科目',
    'form.grade': '年级',
    'form.duration': '持续时间',
    'form.category': '类别',
    'form.type': '类型',
    'form.difficulty': '难度',
    'form.topic': '主题',
    'form.learningStyle': '学习方式',
    'form.questionCount': '问题数量',

    // Buttons and Actions
    'button.createNew': '新建',
    'button.viewAll': '查看全部',
    'button.preview': '预览',
    'button.download': '下载',
    'button.share': '分享',
    'button.print': '打印',
    'button.export': '导出',
    'button.import': '导入',

    // Messages
    'message.noData': '无数据',
    'message.noResults': '未找到结果',
    'message.saveSuccess': '保存成功',
    'message.updateSuccess': '更新成功',
    'message.deleteSuccess': '删除成功',
    'message.saveError': '保存数据时出错',
    'message.updateError': '更新数据时出错',
    'message.deleteError': '删除数据时出错',
    'message.confirmDelete': '确定要删除吗？',
    'message.pleaseWait': '请稍候...',
    'message.processing': '处理中...',

    // Placeholders
    'placeholder.search': '搜索...',
    'placeholder.enterText': '输入文本...',
    'placeholder.selectOption': '选择选项...',
    'placeholder.enterEmail': '输入邮箱...',
    'placeholder.enterPassword': '输入密码...',
    'placeholder.enterName': '输入姓名...',
    'placeholder.enterSchool': '输入学校名称...',
  }
};

interface AppProviderProps {
  children: ReactNode;
}

export const AppProvider: React.FC<AppProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [settings, setSettings] = useState<AppSettings>({
    language: 'th',
    theme: 'light',
    fontSize: 'medium'
  });

  useEffect(() => {
    // Load settings from localStorage
    const savedSettings = localStorage.getItem('appSettings');
    if (savedSettings) {
      setSettings(JSON.parse(savedSettings));
    }

    // Check authentication status
    checkAuthStatus();
  }, []);

  useEffect(() => {
    // Apply theme to document
    const root = document.documentElement;
    if (settings.theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
  }, [settings.theme]);

  const checkAuthStatus = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await loadUserProfile(session.user);
      }
    } catch (error) {
      console.error('Error checking auth status:', error);
    }
  };

  const loadUserProfile = async (supabaseUser: any) => {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', supabaseUser.id)
        .single();

      const userData: User = {
        id: supabaseUser.id,
        email: supabaseUser.email,
        name: profile?.name || supabaseUser.user_metadata?.name || supabaseUser.email,
        role: 'teacher',
        school: profile?.school || supabaseUser.user_metadata?.school,
        subjects: profile?.subjects || [],
        experience: profile?.experience || 0,
        bio: profile?.bio,
        phone: profile?.phone,
        address: profile?.address,
        education: profile?.education || [],
        certifications: profile?.certifications || [],
        socialLinks: profile?.social_links || {},
        avatar: profile?.avatar_url
      };

      setUser(userData);
      setIsAuthenticated(true);
    } catch (error) {
      console.error('Error loading user profile:', error);
    }
  };

  const login = async (email: string, password: string): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password
      });

      if (error) throw error;

      if (data.user) {
        await loadUserProfile(data.user);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Login error:', error);
      return false;
    }
  };

  const register = async (userData: any): Promise<boolean> => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email: userData.email,
        password: userData.password,
        options: {
          data: {
            name: userData.name,
            school: userData.school
          }
        }
      });

      if (error) throw error;

      if (data.user) {
        // Create profile record
        const { error: profileError } = await supabase
          .from('profiles')
          .insert({
            user_id: data.user.id,
            name: userData.name,
            school: userData.school || null
          });

        if (profileError) {
          console.error('Profile creation error:', profileError);
        }

        await loadUserProfile(data.user);
        return true;
      }
      return false;
    } catch (error) {
      console.error('Registration error:', error);
      return false;
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await supabase.auth.signOut();
    } catch (error: any) {
      // Check if the error is related to session not found
      if (error?.message?.includes('session_not_found') || 
          error?.code === 'session_not_found' ||
          (error?.status === 403 && error?.body?.includes('session_not_found'))) {
        // Session doesn't exist on server, which means user is effectively logged out
        // Suppress this error as it's not critical
        console.debug('Session already expired on server');
      } else {
        // Log other errors but don't throw them
        console.error('Logout error:', error);
      }
    } finally {
      // Always clear client-side state regardless of server response
      setUser(null);
      setIsAuthenticated(false);
    }
  };

  const updateUser = async (userData: Partial<User>) => {
    if (!user) return;

    try {
      const { error } = await supabase
        .from('profiles')
        .update({
          name: userData.name,
          school: userData.school,
          subjects: userData.subjects,
          experience: userData.experience,
          bio: userData.bio,
          phone: userData.phone,
          address: userData.address,
          education: userData.education,
          certifications: userData.certifications,
          social_links: userData.socialLinks,
          updated_at: new Date().toISOString()
        })
        .eq('user_id', user.id);

      if (error) throw error;

      setUser({ ...user, ...userData });
    } catch (error) {
      console.error('Error updating user:', error);
    }
  };

  const updateSettings = (newSettings: Partial<AppSettings>) => {
    const updatedSettings = { ...settings, ...newSettings };
    setSettings(updatedSettings);
    localStorage.setItem('appSettings', JSON.stringify(updatedSettings));
  };

  const t = (key: string): string => {
    const translation = translations[settings.language]?.[key];
    return translation || key;
  };

  const generateAIContent = async (type: string, context?: any): Promise<string> => {
    // Simulate AI content generation
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const language = settings.language;
    
    // Enhanced AI content generation with topic-specific questions
    const topicQuestions = {
      th: {
        'ระบบสุริยะ': [
          'ดาวดวงใดเป็นศูนย์กลางของระบบสุริยะ?|ดาวเสาร์|พระอาทิตย์|ดาวพุธ|ดาวอังคาร|1',
          'ดาวเคราะห์ใดอยู่ใกล้พระอาทิตย์ที่สุด?|ดาวพุธ|ดาวศุกร์|โลก|ดาวอังคาร|0',
          'ดาวเคราะห์ใดมีขนาดใหญ่ที่สุดในระบบสุริยะ?|ดาวเสาร์|ดาวพฤหัสบดี|ดาวยูเรนัส|ดาวเนปจูน|1',
          'โลกใช้เวลากี่วันในการโคจรรอบพระอาทิตย์?|365 วัน|360 วัน|370 วัน|355 วัน|0'
        ],
        'การอ่านจับใจความ': [
          'การอ่านจับใจความสำคัญคือการ?|จำรายละเอียดทั้งหมด|เข้าใจประเด็นหลัก|อ่านเร็วที่สุด|จำคำศัพท์ใหม่|1',
          'ขั้นตอนแรกของการอ่านจับใจความคือ?|อ่านทั้งเรื่อง|ดูหัวข้อและภาพ|จดบันทึก|ตั้งคำถาม|1',
          'การหาใจความสำคัญควรมองหา?|ประโยคแรก|ประโยคสุดท้าย|ประโยคหลัก|ประโยคยาวที่สุด|2',
          'การสรุปใจความควรใช้คำ?|เหมือนเดิม|ของตนเอง|ยากๆ|มากที่สุด|1'
        ],
        'เศรษฐกิจพอเพียง': [
          'หลักปรัชญาเศรษฐกิจพอเพียงมีกี่หลัก?|2 หลัก|3 หลัก|4 หลัก|5 หลัก|1',
          'หลักความพอประมาณหมายถึง?|มีมากที่สุด|มีน้อยที่สุด|มีเท่าที่จำเป็น|ไม่มีเลย|2',
          'เงื่อนไขความรู้ในปรัชญาเศรษฐกิจพอเพียงคือ?|รู้มาก|รู้น้อย|รู้เท่าทัน|ไม่รู้|2',
          'ปรัชญาเศรษฐกิจพอเพียงริเริ่มโดย?|พระบาทสมเด็จพระเจ้าอยู่หัว|นายกรัฐมนตรี|รัฐมนตรี|ประชาชน|0'
        ]
      },
      en: {
        'solar system': [
          'Which celestial body is at the center of the solar system?|Saturn|The Sun|Mercury|Mars|1',
          'Which planet is closest to the Sun?|Mercury|Venus|Earth|Mars|0',
          'Which planet is the largest in the solar system?|Saturn|Jupiter|Uranus|Neptune|1',
          'How many days does Earth take to orbit the Sun?|365 days|360 days|370 days|355 days|0'
        ],
        'reading comprehension': [
          'Reading comprehension is the ability to?|Memorize all details|Understand main ideas|Read as fast as possible|Learn new vocabulary|1',
          'The first step in reading comprehension is?|Read the entire text|Look at titles and pictures|Take notes|Ask questions|1',
          'To find the main idea, you should look for?|The first sentence|The last sentence|The topic sentence|The longest sentence|2',
          'When summarizing, you should use?|The same words|Your own words|Difficult words|As many words as possible|1'
        ],
        'sufficiency economy': [
          'How many principles does the Sufficiency Economy Philosophy have?|2 principles|3 principles|4 principles|5 principles|1',
          'The principle of moderation means?|Having the most|Having the least|Having what is necessary|Having nothing|2',
          'The knowledge condition in Sufficiency Economy Philosophy is?|Knowing a lot|Knowing little|Being knowledgeable|Not knowing|2',
          'The Sufficiency Economy Philosophy was initiated by?|His Majesty the King|Prime Minister|Minister|The people|0'
        ]
      },
      zh: {
        '太阳系': [
          '太阳系的中心是哪个天体？|土星|太阳|水星|火星|1',
          '哪个行星离太阳最近？|水星|金星|地球|火星|0',
          '太阳系中最大的行星是？|土星|木星|天王星|海王星|1',
          '地球绕太阳一周需要多少天？|365天|360天|370天|355天|0'
        ],
        '阅读理解': [
          '阅读理解是指？|记住所有细节|理解主要思想|尽可能快地阅读|学习新词汇|1',
          '阅读理解的第一步是？|阅读整篇文章|看标题和图片|做笔记|提问题|1',
          '要找到主要思想，应该寻找？|第一句话|最后一句话|主题句|最长的句子|2',
          '总结时应该使用？|相同的词|自己的词|困难的词|尽可能多的词|1'
        ],
        '足够经济': [
          '足够经济哲学有几个原则？|2个原则|3个原则|4个原则|5个原则|1',
          '适度原则意味着？|拥有最多|拥有最少|拥有必要的|什么都没有|2',
          '足够经济哲学中的知识条件是？|知道很多|知道很少|有知识|不知道|2',
          '足够经济哲学是由谁提出的？|国王陛下|总理|部长|人民|0'
        ]
      }
    };

    const responses = {
      th: {
        'lesson-objectives': `จุดประสงค์การเรียนรู้สำหรับ ${context?.topic || 'หัวข้อนี้'}:
1. เพื่อให้นักเรียนเข้าใจแนวคิดพื้นฐาน
2. เพื่อพัฒนาทักษะการคิดวิเคราะห์
3. เพื่อสามารถนำความรู้ไปประยุกต์ใช้ได้`,
        
        'lesson-activities': `กิจกรรมการเรียนการสอน:
1. กิจกรรมเปิดบทเรียน (10 นาที)
2. กิจกรรมสำรวจความรู้เดิม (15 นาที)
3. กิจกรรมการเรียนรู้หลัก (20 นาที)
4. กิจกรรมฝึกปฏิบัติ (10 นาที)
5. กิจกรรมสรุปและประเมินผล (5 นาที)`,
        
        'lesson-materials': `สื่อและอุปกรณ์:
- กระดานและปากกา
- ใบงานและแบบฝึกหัด
- สื่อประกอบการเรียน
- อุปกรณ์เทคโนโลยี (หากมี)`,
        
        'lesson-assessment': `การวัดและประเมินผล:
- การสังเกตพฤติกรรมการเรียนรู้
- การตรวจแบบฝึกหัด
- การประเมินการมีส่วนร่วม
- แบบทดสอบย่อย`,
        
        'activity-suggestions': `กิจกรรม ${context?.topic || 'การเรียนรู้'}:
1. แบ่งนักเรียนเป็นกลุ่มย่อย
2. ให้แต่ละกลุ่มศึกษาและหารือ
3. นำเสนอผลการศึกษาหน้าชั้น
4. สรุปและแลกเปลี่ยนความคิดเห็น`,
        
        'student-analysis': `การวิเคราะห์นักเรียน:
นักเรียนคนนี้มีผลการเรียนอยู่ในระดับ ${context?.scores?.average || 80}% 
แสดงให้เห็นถึงความสามารถที่ดี ควรส่งเสริมและพัฒนาต่อไป
คำแนะนำ: ให้การสนับสนุนเพิ่มเติมในด้านที่ยังอ่อน`,

        'test-questions': function() {
          const topic = context?.topic?.toLowerCase() || '';
          
          // Check if we have predefined questions for this topic
          for (const [key, questions] of Object.entries(topicQuestions.th)) {
            if (topic.includes(key.toLowerCase())) {
              return questions.join('\n');
            }
          }
          
          // Default questions if no specific topic match
          return `1. อธิบายแนวคิดหลักของ${context?.topic || 'เรื่องนี้'}
2. ยกตัวอย่างการประยุกต์ใช้${context?.topic || 'เรื่องนี้'}ในชีวิตจริง
3. เปรียบเทียบความแตกต่างของแนวคิดต่างๆ ใน${context?.topic || 'เรื่องนี้'}
4. วิเคราะห์ปัญหาที่เกี่ยวข้องกับ${context?.topic || 'เรื่องนี้'}และเสนอแนวทางแก้ไข`;
        }
      },
      en: {
        'lesson-objectives': `Learning objectives for ${context?.topic || 'this topic'}:
1. To help students understand basic concepts
2. To develop analytical thinking skills
3. To enable application of knowledge`,
        
        'lesson-activities': `Teaching activities:
1. Opening activity (10 minutes)
2. Prior knowledge exploration (15 minutes)
3. Main learning activity (20 minutes)
4. Practice activity (10 minutes)
5. Summary and assessment (5 minutes)`,
        
        'lesson-materials': `Materials and equipment:
- Whiteboard and markers
- Worksheets and exercises
- Learning materials
- Technology equipment (if available)`,
        
        'lesson-assessment': `Assessment and evaluation:
- Observation of learning behavior
- Checking exercises
- Participation assessment
- Mini quizzes`,
        
        'activity-suggestions': `Activity for ${context?.topic || 'learning'}:
1. Divide students into small groups
2. Have each group study and discuss
3. Present findings to the class
4. Summarize and exchange opinions`,
        
        'student-analysis': `Student analysis:
This student has a performance level of ${context?.scores?.average || 80}%
showing good ability and should be encouraged to continue developing.
Recommendation: Provide additional support in weaker areas`,

        'test-questions': function() {
          const topic = context?.topic?.toLowerCase() || '';
          
          // Check if we have predefined questions for this topic
          for (const [key, questions] of Object.entries(topicQuestions.en)) {
            if (topic.includes(key.toLowerCase())) {
              return questions.join('\n');
            }
          }
          
          // Default questions if no specific topic match
          return `1. Explain the main concepts of ${context?.topic || 'this topic'}
2. Give examples of real-life applications of ${context?.topic || 'this topic'}
3. Compare differences between various concepts in ${context?.topic || 'this topic'}
4. Analyze problems related to ${context?.topic || 'this topic'} and propose solutions`;
        }
      },
      zh: {
        'lesson-objectives': `${context?.topic || '本主题'}的学习目标：
1. 帮助学生理解基本概念
2. 发展分析思维技能
3. 能够应用所学知识`,
        
        'lesson-activities': `教学活动：
1. 开场活动（10分钟）
2. 先前知识探索（15分钟）
3. 主要学习活动（20分钟）
4. 练习活动（10分钟）
5. 总结和评估（5分钟）`,
        
        'lesson-materials': `材料和设备：
- 白板和马克笔
- 工作表和练习
- 学习材料
- 技术设备（如有）`,
        
        'lesson-assessment': `评估和评价：
- 观察学习行为
- 检查练习
- 参与度评估
- 小测验`,
        
        'activity-suggestions': `${context?.topic || '学习'}活动：
1. 将学生分成小组
2. 让每组学习和讨论
3. 向全班展示发现
4. 总结和交流意见`,
        
        'student-analysis': `学生分析：
该学生的表现水平为${context?.scores?.average || 80}%
显示出良好的能力，应该鼓励继续发展。
建议：在较弱的领域提供额外支持`,

        'test-questions': function() {
          const topic = context?.topic?.toLowerCase() || '';
          
          // Check if we have predefined questions for this topic
          for (const [key, questions] of Object.entries(topicQuestions.zh)) {
            if (topic.includes(key.toLowerCase())) {
              return questions.join('\n');
            }
          }
          
          // Default questions if no specific topic match
          return `1. 解释${context?.topic || '本主题'}的主要概念
2. 举出${context?.topic || '本主题'}在现实生活中的应用例子
3. 比较${context?.topic || '本主题'}中各种概念的差异
4. 分析与${context?.topic || '本主题'}相关的问题并提出解决方案`;
        }
      }
    };
    
    if (type === 'test-questions') {
      return responses[language]?.[type]() || 
             responses['th'][type]() || 
             'เนื้อหาที่สร้างโดย AI';
    }
    
    return responses[language]?.[type as keyof typeof responses[typeof language]] || 
           responses['th'][type as keyof typeof responses['th']] || 
           'เนื้อหาที่สร้างโดย AI';
  };

  // Database operations
  const saveLessonPlan = async (lessonData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('lesson_plans')
        .insert({
          teacher_id: user.id,
          title: lessonData.title,
          subject: lessonData.subject,
          grade: lessonData.grade,
          duration: parseInt(lessonData.duration),
          objectives: lessonData.objectives,
          activities: lessonData.activities,
          materials: lessonData.materials,
          assessment: lessonData.assessment
        });

      return !error;
    } catch (error) {
      console.error('Error saving lesson plan:', error);
      return false;
    }
  };

  const getLessonPlans = async (): Promise<any[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('lesson_plans')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      return data || [];
    } catch (error) {
      console.error('Error fetching lesson plans:', error);
      return [];
    }
  };

  const updateLessonPlan = async (id: string, lessonData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('lesson_plans')
        .update({
          title: lessonData.title,
          subject: lessonData.subject,
          grade: lessonData.grade,
          duration: parseInt(lessonData.duration),
          objectives: lessonData.objectives,
          activities: lessonData.activities,
          materials: lessonData.materials,
          assessment: lessonData.assessment,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('teacher_id', user.id);

      return !error;
    } catch (error) {
      console.error('Error updating lesson plan:', error);
      return false;
    }
  };

  const saveActivity = async (activityData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('activities')
        .insert({
          teacher_id: user.id,
          name: activityData.name,
          description: activityData.description,
          category: activityData.category,
          duration: parseInt(activityData.duration),
          group_size: activityData.groupSize,
          objectives: activityData.objectives,
          instructions: activityData.instructions,
          materials: activityData.materials
        });

      return !error;
    } catch (error) {
      console.error('Error saving activity:', error);
      return false;
    }
  };

  const getActivities = async (): Promise<any[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('activities')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      return data || [];
    } catch (error) {
      console.error('Error fetching activities:', error);
      return [];
    }
  };

  const updateActivity = async (id: string, activityData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('activities')
        .update({
          name: activityData.name,
          description: activityData.description,
          category: activityData.category,
          duration: parseInt(activityData.duration),
          group_size: activityData.groupSize,
          objectives: activityData.objectives,
          instructions: activityData.instructions,
          materials: activityData.materials,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('teacher_id', user.id);

      return !error;
    } catch (error) {
      console.error('Error updating activity:', error);
      return false;
    }
  };

  const saveTest = async (testData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('tests')
        .insert({
          teacher_id: user.id,
          title: testData.title,
          subject: testData.subject,
          grade: testData.grade,
          duration: parseInt(testData.duration),
          instructions: testData.instructions,
          questions: testData.questions,
          total_points: testData.totalPoints,
          is_published: testData.isPublished || false
        });

      return !error;
    } catch (error) {
      console.error('Error saving test:', error);
      return false;
    }
  };

  const getTests = async (): Promise<any[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('tests')
        .select('*')
        .eq('teacher_id', user.id)
        .order('created_at', { ascending: false });

      return data || [];
    } catch (error) {
      console.error('Error fetching tests:', error);
      return [];
    }
  };

  const updateTest = async (id: string, testData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('tests')
        .update({
          title: testData.title,
          subject: testData.subject,
          grade: testData.grade,
          duration: parseInt(testData.duration),
          instructions: testData.instructions,
          questions: testData.questions,
          total_points: testData.totalPoints,
          is_published: testData.isPublished || false,
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('teacher_id', user.id);

      return !error;
    } catch (error) {
      console.error('Error updating test:', error);
      return false;
    }
  };

  // Student management functions
  const saveStudent = async (studentData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('students')
        .insert({
          teacher_id: user.id,
          student_id: studentData.studentId,
          name: studentData.name,
          grade: studentData.grade,
          class: studentData.class,
          photo_url: studentData.photoUrl,
          personality: studentData.personality || {},
          academic_data: studentData.academicData || {},
          behavioral_data: studentData.behavioralData || {},
          notes: studentData.notes || []
        });

      return !error;
    } catch (error) {
      console.error('Error saving student:', error);
      return false;
    }
  };

  const getStudents = async (): Promise<any[]> => {
    if (!user) return [];
    
    try {
      const { data, error } = await supabase
        .from('students')
        .select('*')
        .eq('teacher_id', user.id)
        .order('name', { ascending: true });

      return data || [];
    } catch (error) {
      console.error('Error fetching students:', error);
      return [];
    }
  };

  const updateStudent = async (id: string, studentData: any): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('students')
        .update({
          student_id: studentData.studentId,
          name: studentData.name,
          grade: studentData.grade,
          class: studentData.class,
          photo_url: studentData.photoUrl,
          personality: studentData.personality || {},
          academic_data: studentData.academicData || {},
          behavioral_data: studentData.behavioralData || {},
          notes: studentData.notes || [],
          updated_at: new Date().toISOString()
        })
        .eq('id', id)
        .eq('teacher_id', user.id);

      return !error;
    } catch (error) {
      console.error('Error updating student:', error);
      return false;
    }
  };

  const deleteStudent = async (id: string): Promise<boolean> => {
    if (!user) return false;
    
    try {
      const { error } = await supabase
        .from('students')
        .delete()
        .eq('id', id)
        .eq('teacher_id', user.id);

      return !error;
    } catch (error) {
      console.error('Error deleting student:', error);
      return false;
    }
  };

  const value: AppContextType = {
    user,
    isAuthenticated,
    settings,
    login,
    register,
    logout,
    updateUser,
    updateSettings,
    t,
    generateAIContent,
    saveLessonPlan,
    getLessonPlans,
    updateLessonPlan,
    saveActivity,
    getActivities,
    updateActivity,
    saveTest,
    getTests,
    updateTest,
    saveStudent,
    getStudents,
    updateStudent,
    deleteStudent
  };

  return (
    <AppContext.Provider value={value}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};